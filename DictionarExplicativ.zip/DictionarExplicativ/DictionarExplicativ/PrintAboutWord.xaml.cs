﻿using System.Windows;
using System.IO;
using System.Windows.Media.Imaging;
using System;

namespace DictionarExplicativ
{

    public partial class PrintAboutWord : Window
    {
        private string title;
        public PrintAboutWord(string title)
        {
            InitializeComponent();
            this.title = title;
            Printing();
        }
        private void Printing()
        {
            string[] lines = File.ReadAllLines("D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt");
            foreach (string line in lines)
            {
                string[] parts = line.Split(',');
                if (parts[1] == title) 
                {
                    word.Text = title;
                    category.Text = parts[0];
                    description.Text = parts[2];
                    if (parts[3] != "") 
                        image.Source = new BitmapImage(new Uri(parts[3]));
                    else
                        image.Source = new BitmapImage(new Uri("C:\\Users\\Casi\\Pictures\\nonimage.png"));
                }             
            }
        }
    }
}
