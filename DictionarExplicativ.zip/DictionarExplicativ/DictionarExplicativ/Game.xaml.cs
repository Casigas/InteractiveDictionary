﻿using System.Collections.Generic;
using System.Windows;
using System.IO;
using System.Windows.Shapes;
using System.Windows.Controls;
using System.Windows.Media.Imaging;
using System;
using System.Windows.Media;

namespace DictionarExplicativ
{

    public partial class Game : Window
    {
        private int nextButtonClickCount = 0;
        private int contorForGame = 0;
        private string corectWord;
        private string wordFromTextBox;
        public Game()
        {
            InitializeComponent();
            if(nextButtonClickCount == 0)
            {
                generateImageOrExplanation();
            }
            else if(nextButtonClickCount == 5)
            {
                MessageBox.Show("Congratulations, the game is over, you have " + corectWord + " corect answers!");
            }
        }

        private void generateImageOrExplanation()
        {
            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            string[] lines = File.ReadAllLines(filePath);

            
            Random random = new Random();
            int randomIndex = random.Next(0, lines.Length); 

            string[] parts = lines[randomIndex].Split(',');

            
            int randomDecision = random.Next(0, 2);
            corectWord = parts[1];
            if (randomDecision == 0 && String.IsNullOrEmpty(parts[3]))
            {
                string imageSource = parts[3];
                Image image = new Image();
                image.Source = new BitmapImage(new Uri(imageSource));
                image.VerticalAlignment = VerticalAlignment.Center;
                image.HorizontalAlignment = HorizontalAlignment.Center;
                image.Width = 100; 
                image.Height = 100; 
                image.Stretch = Stretch.Uniform;
                myGrid.Children.Add(image);              
            }
            else
            {
                string description = parts[2];
                TextBlock descriptionTextBlock = new TextBlock();
                descriptionTextBlock.Text = description;
                descriptionTextBlock.FontSize = 18;
                descriptionTextBlock.TextAlignment = TextAlignment.Center;
                descriptionTextBlock.VerticalAlignment = VerticalAlignment.Center;
                descriptionTextBlock.HorizontalAlignment = HorizontalAlignment.Center;
                myGrid.Children.Add(descriptionTextBlock);
            }
        }

        private void txtAnswer_TextChanged(object sender, System.Windows.Controls.TextChangedEventArgs e)
        {
            wordFromTextBox = txtAnswer.Text;
        }

        private void NextButton_Click(object sender, RoutedEventArgs e)
        {
            if (corectWord == wordFromTextBox)
            {
                contorForGame++;
                MessageBox.Show("Corect!");
            }
            else
            {
                MessageBox.Show("Incorect, the answer was " + corectWord + "!");
            }
            nextButtonClickCount++;
            if (nextButtonClickCount >= 5)
            {
                NButton.Visibility = Visibility.Collapsed;
            }
            if (nextButtonClickCount == 5)
            {
                MessageBox.Show("Congratulations, the game is over, you have " + contorForGame + " corect words from 5!");
            }
            List<UIElement> elementsToKeep = new List<UIElement>();

            
            foreach (UIElement child in myGrid.Children)
            {
               
                if (child is TextBlock textBlock &&
                    (textBlock.Text == "Look a hint:" || textBlock.Text == "Write your answer:"))
                {
                    
                    elementsToKeep.Add(child);
                }
                else if (child is TextBox textBox && textBox.Name == "txtAnswer")
                {
                    
                    elementsToKeep.Add(child);
                }
                else if (child is Button button && button.Name == "NButton")
                {
                   
                    elementsToKeep.Add(child);
                }
            }

            
            myGrid.Children.Clear();

            
            foreach (UIElement element in elementsToKeep)
            {
                myGrid.Children.Add(element);
            }
            generateImageOrExplanation();
        }
    }
}
