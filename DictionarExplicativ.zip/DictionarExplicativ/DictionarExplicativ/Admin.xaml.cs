﻿using System.Collections.Generic;
using System.Windows;
using System.IO;
using System.Windows.Shapes;
using System.Windows.Controls;


namespace DictionarExplicativ
{
    public partial class Admin : Window
    {
        public List<string> categories { get; set; }
        public Admin()
        {
            InitializeComponent();
            if (categories == null)
                categories = new List<string>();
        }
            
        private void AddWord_Click(object sender, RoutedEventArgs e)
        {
            Word wordWindow = new Word(this); // Furnizează referința către obiectul Admin curent
            wordWindow.Show();
            //this.Close();
        }

    }
}
