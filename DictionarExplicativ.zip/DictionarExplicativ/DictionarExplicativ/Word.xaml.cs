﻿using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DictionarExplicativ
{
    public partial class Word : Window
    {
        private Admin adminWindow;

        public Word(Admin adminWindow)
        {
            InitializeComponent();
            this.adminWindow = adminWindow;
        }

        private void WordComplete_Click(object sender, RoutedEventArgs e)
        {
            string title = txtTitle.Text;
            string description = txtDescription.Text;
            string category = txtCategory.Text;
            string imagePath = txtImagePath.Text;

            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            using (StreamWriter sw = File.AppendText(filePath))
            {
                // Se scriu datele în fișier, separate de virgulă sau alt separator, după preferințe
                sw.WriteLine($"{category},{title},{description},{imagePath}");
            }

            if (adminWindow == null || adminWindow.categories == null)
            {
                MessageBox.Show("Error: Admin window or categories list is not initialized.");
                return;
            }

            bool categoryExists = adminWindow.categories.Contains(category);
            if (categoryExists)
            {
                Button newTextButton = new Button();
                newTextButton.Content = title;
                newTextButton.Background = Brushes.LightBlue;
                newTextButton.FontSize = 16;
                Button localButton2 = newTextButton;
                newTextButton.Click += (s, args) =>
                {
                    DeleteModify deleteModify = new DeleteModify(adminWindow, localButton2);
                    deleteModify.Show();
                };
                int index = adminWindow.categories.IndexOf(category);
                if (index == 0)
                    adminWindow.categoriesPanel.Children.Insert(index + 1, newTextButton);
                else if (index == 1)
                    adminWindow.categoriesPanel.Children.Insert(index + 5, newTextButton);
                else if (index == 2)
                    adminWindow.categoriesPanel.Children.Insert(index + 8, newTextButton);
                else if (index == 3)
                    adminWindow.categoriesPanel.Children.Insert(index + 9, newTextButton);
                // adminWindow.categoriesPanel.Children.Add(newTextButton);
                adminWindow.Show();
                this.Close();
            }
            else
            {
                MessageBox.Show("The category you mentioned does not exist, please add it!");
            }
        }

        private void NewCategory_Click(object sender, RoutedEventArgs e)
        {
            if (adminWindow == null || adminWindow.categories == null)
            {
                MessageBox.Show("Error: Admin window or categories list is not initialized.");
                return;
            }

            string category = txtNewCategory.Text;
            adminWindow.categories.Add(category);
            TextBlock newTitle = new TextBlock();
            newTitle.Text = category + ':';
            newTitle.FontSize = 12;
            newTitle.Margin = new Thickness(0, 40, 80, 30);
            adminWindow.categoriesPanel.Children.Add(newTitle);
            MessageBox.Show("Category added successfully");
        }
    }
}
