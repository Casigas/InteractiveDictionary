﻿using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;

namespace DictionarExplicativ
{
    public partial class MainWindow : Window
    {
        
        public MainWindow()
        {
            InitializeComponent();
        }
        private void LoginAdmin(object sender, RoutedEventArgs e)
        {
            AdministratorLogin admin = new AdministratorLogin();
            admin.Show();
            this.Close();
        }

        private void Button_Click(object sender, RoutedEventArgs e) //FindWord
        {
            FindWord find = new FindWord(); 
            find.Show();
            this.Close();
        }

        private void Button_Click_1(object sender, RoutedEventArgs e) //PlayGame
        {
            Game game = new Game();
            game.Show();
            this.Close();
        }
    }
}
