﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
using System.Windows.Controls;

namespace DictionarExplicativ
{
    public partial class FindWord : Window
    {
        private Dictionary<string, List<string>> categoriesAndWords;

        public FindWord()
        {
            InitializeComponent();
            LoadCategoriesAndWordsFromFile();
        }

        private void LoadCategoriesAndWordsFromFile()
        {
            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            if (File.Exists(filePath))
            {
                categoriesAndWords = new Dictionary<string, List<string>>();

                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    string category = parts[0];
                    string word = parts[1];

                    if (categoriesAndWords.ContainsKey(category))
                    {
                        categoriesAndWords[category].Add(word);
                    }
                    else
                    {
                        List<string> words = new List<string> { word };
                        categoriesAndWords.Add(category, words);
                    }
                }

                foreach (var category in categoriesAndWords)
                {
                    categoryComboBox.Items.Add(new ComboBoxItem { Content = category.Key });
                }
            }
            else
            {
                MessageBox.Show("Fișierul cu categorii nu există sau nu poate fi accesat.");
            }
        }

        private void categoryComboBox_SelectionChanged(object sender, System.Windows.Controls.SelectionChangedEventArgs e)
        {
            if (categoryComboBox.SelectedItem != null)
            {
                string selectedCategory = ((ComboBoxItem)categoryComboBox.SelectedItem).Content.ToString();
                List<string> words = categoriesAndWords[selectedCategory];

                wordComboBox.Items.Clear();
                foreach (string word in words)
                {
                    wordComboBox.Items.Add(word);
                }
            }
        }

       

        private void inputTextBox_TextChanged(object sender, TextChangedEventArgs e)
        {
            string inputText = inputTextBox.Text.ToLower();
            List<string> suggestions = new List<string>();
            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            if (File.Exists(filePath))
            {
                string[] lines = File.ReadAllLines(filePath);
                foreach (string line in lines)
                {
                    string[] parts = line.Split(',');
                    string word = parts[1];
                    if (word.ToLower().StartsWith(inputText))
                    {
                        suggestions.Add(word);
                    }
                }
                suggestions.Sort();
                wordComboBox2.Items.Clear();
                foreach (string suggestion in suggestions)
                {
                    wordComboBox2.Items.Add(suggestion);
                }
            }
        }
        private void wordComboBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (wordComboBox.SelectedItem != null)
            {
                string selectedWord = wordComboBox.SelectedItem.ToString();
                PrintAboutWord p = new PrintAboutWord(selectedWord);
                p.Show();
                this.Close();
            }   
        }
        private void wordComboBox2_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {
            if (wordComboBox2.SelectedItem != null)
            {
                string selectedWord = wordComboBox2.SelectedItem.ToString();
                PrintAboutWord p = new PrintAboutWord(selectedWord);
                p.Show();
                this.Close();
            }
        }
    }
}
