﻿using System.Collections.Generic;
using System.IO;
using System.Reflection;
using System.Windows;
using System.Windows.Controls;

namespace DictionarExplicativ
{

    public partial class DeleteModify : Window
    {
        private Admin admin;
        private Button button;
        public DeleteModify(Admin admin, Button button)
        {
            InitializeComponent();
            this.admin = admin;
            this.button = button;
        }

        private void Modify_Click(object sender, RoutedEventArgs e)
        {
            admin.categoriesPanel.Children.Remove(button);
            button.Content = txtModify.Text;
            admin.categoriesPanel.Children.Insert(1, button);
            this.Close();
        }

        private void Delete_Click(object sender, RoutedEventArgs e)
        {
            admin.categoriesPanel.Children.Remove(button);
            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            string word = button.Content.ToString();

            List<string> newLines = new List<string>();
            foreach (string line in File.ReadLines(filePath))
            {
                if (!line.Contains(word))
                    newLines.Add(line);
            }
            File.WriteAllLines(filePath, newLines);

            this.Close();
        }
    }
}
