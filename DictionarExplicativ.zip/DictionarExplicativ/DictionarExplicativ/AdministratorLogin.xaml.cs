﻿using System;
using System.IO;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Media;



namespace DictionarExplicativ
{

    public partial class AdministratorLogin : Window
    {
        public AdministratorLogin()
        {
            InitializeComponent();
        }
        private void Login_Click(object sender, RoutedEventArgs e)
        {
            string[] lines = File.ReadAllLines("D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\Credentiale.txt");
            bool authentification = false;
            foreach (string line in lines)
            {
                string[] half = line.Split('-');
                string username = half[0];
                string password = half[1];

                string userFromLoginTab = txtUsername.Text;
                string passFromLoginTab = txtPassword.Password;

                if (userFromLoginTab == username && passFromLoginTab == password) 
                {
                    Admin admin = new Admin();
                    admin.Show();
                    printDataFromPast(admin);
                    this.Close();
                    authentification = true;
                    break;
                }
            }
            if (!authentification)
                MessageBox.Show("Username or password are wrong!");
        }
        private void printDataFromPast(Admin admin)
        {
            string filePath = "D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt";
            string[] lines = File.ReadAllLines(filePath);

            // Sortarea liniilor alfabetic după primul cuvânt al fiecărei linii
            Array.Sort(lines, (x, y) => x.Split(',')[0].CompareTo(y.Split(',')[0]));

            string copy = string.Empty; // Variabila pentru a ține evidența categoriei curente

            foreach (string line in lines)
            {
                string[] parts = line.Split(',');

                if (parts.Length >= 2) // Verificăm dacă linia are cel puțin două părți (categorie și cuvânt)
                {
                    string category = parts[0];
                    string word = parts[1];

                    // Adăugăm titlul categoriei dacă este diferit de cel anterior
                    if (category != copy)
                    {
                        copy = category;
                        TextBlock newTitle = new TextBlock();
                        newTitle.Text = category + ":";
                        newTitle.FontSize = 12;
                        newTitle.Margin = new Thickness(0, 40, 80, 30);
                        admin.categoriesPanel.Children.Add(newTitle);
                        admin.categories.Add(category);
                    }

                    // Adăugăm butonul pentru cuvântul din linie
                    Button newTextButton = new Button();
                    newTextButton.Content = word;
                    newTextButton.Background = Brushes.LightBlue;
                    newTextButton.FontSize = 16;
                    Button localButton = newTextButton;
                    newTextButton.Click += (sender, e) =>
                    {
                        DeleteModify deleteModify = new DeleteModify(admin, localButton);
                        deleteModify.Show();
                    };
                    admin.categoriesPanel.Children.Add(newTextButton);
                }
            }
        }

        //private void printDataFromPast(Admin admin)
        //{
        //    string[] lines = File.ReadAllLines("D:\\MVP\\DictionarExplicativ\\DictionarExplicativ\\WordsFile.txt");
        //    string firstline = lines[0];
        //    string[] parts = firstline.Split(',');
        //    string copy = parts[0];
        //    TextBlock newTitle = new TextBlock();
        //    newTitle.Text = parts[0] + ':';
        //    newTitle.FontSize = 12;
        //    newTitle.Margin = new Thickness(0, 40, 80, 30);
        //    admin.categoriesPanel.Children.Add(newTitle);
        //    Button newTextButton = new Button();
        //    newTextButton.Content = parts[1];
        //    newTextButton.Background = Brushes.LightBlue;
        //    newTextButton.FontSize = 16;
        //    Button localButton1 = newTextButton;
        //    newTextButton.Click += (sender, e) =>
        //    {
        //        DeleteModify deleteModify = new DeleteModify(admin, localButton1);
        //        deleteModify.Show();
        //    };
        //    admin.categoriesPanel.Children.Add(newTextButton);
        //    admin.categories.Add(parts[0]);
        //    foreach (string line in lines)
        //    {
        //        if (line != lines[0])
        //        {
        //            parts = line.Split(',');
        //            if (parts[0] != copy)
        //            {
        //                copy = parts[0]; 
        //                newTitle = new TextBlock();
        //                newTitle.Text = parts[0] + ':';
        //                newTitle.FontSize = 12;
        //                newTitle.Margin = new Thickness(0, 40, 80, 30);
        //                admin.categoriesPanel.Children.Add(newTitle);
        //                admin.categories.Add(parts[0]);
        //            }
        //            newTextButton = new Button();
        //            newTextButton.Content = parts[1];
        //            newTextButton.Background = Brushes.LightBlue;
        //            newTextButton.FontSize = 16;
        //            Button localButton = newTextButton;
        //            newTextButton.Click += (sender, e) =>
        //            {
        //                DeleteModify deleteModify = new DeleteModify(admin, localButton);
        //                deleteModify.Show();
        //            };
        //            admin.categoriesPanel.Children.Add(newTextButton);

        //        } 
        //    }
        //}
    }
}
